<template>
  <div>
    <button @click="debounce(debounceTest,1000)('hi，函数防抖')">模拟函数防抖事件触发</button>
    <button @click="debounce(debounceTest1,1000)('hi，函数防抖1')">模拟函数防抖事件触发1</button>
  </div>
</template>
<script>
import util from "./util.js";
export default {
  methods: {
    debounce: util.debounce,
    debounceTest(message) {
      console.log("执行了打印代码", message);
    },
    debounceTest1(message) {
      console.log("执行了打印代码1", message);
    }
  },
  created(){
    setInterval(util.debounce(this.debounceTest, 500), 1000, 'hi，自动防抖测试')
  }
};
</script>