<template>
  <button @click="markRequest('hi')">模拟发起http请求</button>
</template>
<script>
import util from './util.js'
export default {
  methods: {
    async markRequest(text) {
      let url = `https://www.baidu.com/s`
      let res = await util.get(url, {wd: text})
      console.log("result",res)
    }
  }
};
</script>