import axios from "axios";

const MAX_RETRY = 3  // 重试次数
const RETRY_INTERVAL = 500 // 重试间隔500ms
const TIMEOUT = 15 * 1000 //超时时间

function sleep(ms){
  return new Promise((resolve)=>setTimeout(resolve,ms));
}

async function request(url, method, params, retry = MAX_RETRY, hookResult = null){
  let res
  let requireRetry
  try {
    let config = {
      url: url,
      method: method,
      timeout: TIMEOUT
    }
    if (Object.is(method, 'get')){
      config['params'] = params
    }else if (Object.is(method, 'post')){
      config['data'] = params
    }
    res = await axios.request(config)
    // 发生服务器错误，重试
    if (res && res.status >= 500) requireRetry = true
    // 使用调用者逻辑判断，如果未达期许，重试
    if (hookResult && !hookResult(res)) requireRetry = true
  }catch(err){
    console.log(err)
    // 发生网络错误，重试
    requireRetry = true
  }
  if (requireRetry && retry > 0){
    // 500ms之后重试
    await sleep(RETRY_INTERVAL)
    console.log('重试', retry)
    res = await request(url, method, params, --retry, hookResult)
  }
  return res
}
function get(url, params = {}, retry = MAX_RETRY, hookResult = null){
  return request(url, 'get', {}, retry, hookResult)
}
function post(url, data = {}, retry = MAX_RETRY, hookResult = null){
  return request(url, 'post', data, retry, hookResult)
}
export default {
  request,
  get,
  post
}